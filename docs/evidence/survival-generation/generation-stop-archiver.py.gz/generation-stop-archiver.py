from pathlib import Path
import json,gzip,hashlib,subprocess,re
from datetime import datetime,timezone
base=Path('.local');dest=Path('docs/evidence/survival-generation');artifacts=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def archive(src,name=None):
 data=src.read_bytes();p=dest/((name or src.name)+'.gz');packed=gzip.compress(data,mtime=0)
 if p.exists():assert gzip.decompress(p.read_bytes())==data
 else:p.write_bytes(packed)
 assert gzip.decompress(p.read_bytes())==data
 artifacts.append(dict(path='survival-generation/'+p.name,bytes=len(data),sha256=sha(data),gzip_sha256=sha(p.read_bytes())))
cases=[]
for case,pin in [('generated-smoke-c','c67410a'),('generated-live-a','c67410a'),('generated-live-b','da9bdd0'),('generated-live-c','da9bdd0')]:
 stem='survival-roof-20261002-'+case
 r=dict(case=case,source=subprocess.check_output(['git','rev-parse',pin],text=True).strip())
 p=base/(stem+'.json')
 if p.exists():
  x=json.loads(p.read_text());r.update(execute=x['execute'],error=x['error'],phases=[e['phase'] for e in x['events']],retained_receive_windows_complete=all(t['complete'] for t in x['traces']) and x['observer_trace']['complete'])
  r['placement_mining_motion_dispatch_absent_in_history']=all(x['history'][k] is None for k in ('placement','mining','survival_motion')) and x['history']['motion']['last_submission'] is None
  r['inventory_swap_uncertain']=x['history']['pending_inventory_swap'] is not None
  for e in x['events']:
   if e['phase']=='generated_plan_result':
    z=e['result'];r['generation_passed']='Ok' in z
    if 'Ok' in z:r.update(generated_steps=len(z['Ok']['plan']['steps']),search=z['Ok']['search'])
  log=(base/(stem+'-test.log')).read_text();r['test_seconds_including_fixture']=float(re.findall(r'finished in ([\d.]+)s',log)[-1])
 else:r.update(execute=False,test_started=False,error='fixture readiness exceeded 60 seconds; server later became ready and stopped normally')
 journal=base/(stem+'.json.journal/record.json')
 if journal.exists():
  j=json.loads(journal.read_text());r.update(completed_steps=j['completed_steps'],continuation=j['continuation'],outcome=j['outcome']);archive(journal,stem+'-journal.json')
 for suffix in ('.json','-test.log','-server-console.log','-server.log'):
  q=base/(stem+suffix)
  if q.exists():archive(q)
 cases.append(r)
for suffix in ('tests','clippy'):archive(base/('survival-generator-async-'+suffix+'.log'))
archive(base/'run-roof-trial.py','generation-trial-controller-startup180.py')
hs=base/'survival-mining-server-20261002/hs_err_pid160498.log'
# Preserve only the crash summary/stack publicly: the full JVM report includes environment data.
lines=hs.read_text().splitlines();excerpt='\n'.join(lines[:53])+'\n';p=base/'survival-generation-jvm-crash-summary.txt';p.write_text(excerpt);archive(p)
archive(Path(__file__),'generation-stop-archiver.py')
r=dict(schema='dustroute.survival-generation-stop.v1',recorded_at_utc=datetime.now(timezone.utc).isoformat(),status='stopped_at_new_environment_prerequisite',stage_2_complete=False,generated_roof_live_execution_completed=False,native_vendor_source=json.loads(Path('vendor/voxrig-source.json').read_text())['revision'],cases=cases,crash=dict(process='isolated vanilla Java server',signal='SIGSEGV',thread='C2 CompilerThread0',frame='PhaseChaitin::post_allocate_copy_removal()+0xa0b',java='OpenJDK 21.0.12+8-1-26.04-Ubuntu',full_report_local=str(hs.resolve()),full_report_sha256=sha(hs.read_bytes()),root_cause='undetermined'),limits=['The complete 115-action generated plan passes hypothetical admission, but no generated roof has completed actual execution.','Live A timed out while synchronous planning blocked client I/O; its attempted inventory swap remains uncertain and was not replayed.','Off-thread planning was added and unit tests/Clippy passed. Live C crashed in the JVM before fresh executor admission; this does not establish transport liveness through a successful long execution.','Live B did not start the Rust test; startup exceeded fixture readiness timeout. Live C used 180-second startup timeout; operation deadlines and physics contracts were unchanged.','All dependent live validation and roadmap stages stopped; no JDK changes or repeated crash experiments performed.','Original authored roof acceptance remains separate evidence.'],artifacts=artifacts)
Path('docs/evidence/survival-generation-stop-20261002.json').write_text(json.dumps(r,indent=2)+'\n')
p=Path('docs/evidence/survival-generation-progress-20261002.json');r=json.loads(p.read_text());r['limits'].append('Long synchronous read-only preflights do not establish client transport liveness; see survival-generation-stop-20261002.json for the timeout, async scheduling correction and subsequent JVM crash.');p.write_text(json.dumps(r,indent=2)+'\n')
print('Archived',len(cases),'cases and',len(artifacts),'artifacts; hashes verified.')
