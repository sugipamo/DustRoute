from pathlib import Path
import json,gzip,hashlib,collections,re
from datetime import datetime,timezone
base=Path('.local');dest=Path('docs/evidence/survival-generation');stem='survival-roof-20261002-generated-live-temurin-a'
x=json.loads((base/(stem+'.json')).read_text());j=json.loads((base/(stem+'.json.journal/record.json')).read_text());m=json.loads((base/(stem+'-runtime.json')).read_text())
assert x['execute'] and x['error'] is None and x['disconnect_error'] is None
assert m['test_exit_code']==m['server_exit_code']==0
assert j['continuation']=='completed' and j['outcome']=='observed'
assert x['events'][-1]['phase']=='complete_roof' and x['events'][-1]['record']==j
r=x['events'][0]['result']['Ok'];plan=r['plan'];assert plan==j['plan']['plan']
assert len(plan['steps'])==j['completed_steps']==115
counts=collections.Counter(s['kind'] for s in plan['steps']);assert dict(counts)==dict(place=67,move=30,remove_temporary=18)
assert sum(s['kind']=='place' and s['purpose']=='permanent' for s in plan['steps'])==49
assert plan['materials']['required_supplied']=={'minecraft:cobblestone':49,'minecraft:dirt':18}
final=j['events'][-1];assert final['phase']=='completed';e=final['evidence']
assert e['remaining_owned_temporary']==[] and e['independently_checked_cells']==3120
assert e['position']==plan['final_position']
assert all(plan['scope']['retreat']['min'][i]<=e['position'][i]<=plan['scope']['retreat']['max'][i] for i in range(3))
assert j['reconnects']==18
assert sum(z['phase']=='reconnect_boundary_verified' for z in j['events'])==18
assert all(t['complete'] for t in x['traces']) and x['observer_trace']['complete']
assert not any(z['phase']=='stopped' for z in j['events'])
assert m['removed_java_option_environment_names']==[]
assert m['flags']==['-XX:ActiveProcessorCount=1','-Xms256m','-Xmx768M']
assert 'Temurin-21.0.12.1+1' in m['java_version']
assert json.loads((base/'survival-mining-server-20261002/ops.json').read_text())==[]
props=dict(l.split('=',1) for l in (base/'survival-mining-server-20261002/server.properties').read_text().splitlines() if '=' in l and not l.startswith('#'))
assert props['level-name']==stem and props['gamemode']=='survival' and props['force-gamemode']=='true'
assert props['server-ip']=='127.0.0.1' and props['server-port']=='25572'
artifacts=[]
def archive(src,name=None):
 b=src.read_bytes();out=dest/((name or src.name)+'.gz');z=gzip.compress(b,mtime=0)
 if out.exists():assert gzip.decompress(out.read_bytes())==b
 else:out.write_bytes(z)
 assert gzip.decompress(out.read_bytes())==b
 artifacts.append({'path':'survival-generation/'+out.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gzip_sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
for suffix in ('.json','-runtime.json','-test.log','-server-console.log','-server.log'):archive(base/(stem+suffix))
archive(base/(stem+'.json.journal/record.json'),stem+'-journal.json')
archive(base/'run-roof-trial.py','generation-trial-controller-temurin.py')
archive(Path(__file__),'generation-acceptance-archiver.py')
progress=[p for p in m['progress'] if 'StepCompleted' in p['message']]
log=(base/(stem+'-test.log')).read_text();seconds=float(re.findall(r'finished in ([\d.]+)s',log)[-1])
report={'schema':'dustroute.survival-generation-acceptance.v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'status':'generated_roof_live_acceptance_passed','stage_2_complete':True,'later_roadmap_stages_complete':False,'source':m['source'],'native_source':json.loads(Path('vendor/voxrig-source.json').read_text())['revision'],'case':stem,'runtime':m,'jdk_archive':{'release':'jdk-21.0.12.1+1','url':'https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.12.1%2B1/OpenJDK21U-jdk_x64_linux_hotspot_21.0.12.1_1.tar.gz','sha256':'ce79869e1307ed8ee1e2baa86a412b1eb5b75d10a01006d788a6f968bcfaee94','verified_against':'GitHub release asset digest and upstream checksum file'},'fixture':{'ops':[],'properties':{k:props[k] for k in ['gamemode','force-gamemode','difficulty','enable-command-block','server-ip','server-port','level-name']},'console_usage':'initial flat ground/air, player teleport and supplied inventory only; all construction through native non-OP survival actions'},'generated_actions':dict(counts),'permanent_placements':49,'temporary_placements_and_removals':18,'materials':plan['materials'],'search':r['search'],'completed_steps':j['completed_steps'],'verified_reconnect_boundaries':18,'final_evidence':e,'all_retained_receive_windows_complete':True,'timing':{'test_seconds_including_fixture_and_planning':seconds,'controller_seconds_including_server_start_stop':m['total_seconds'],'controller_seconds_until_first_completed_action':progress[0]['elapsed_seconds'],'seconds_between_first_and_last_completed_actions':progress[-1]['elapsed_seconds']-progress[0]['elapsed_seconds']},'limits':['One complete generated reference roof passed; this is not a claim of arbitrary-building completeness or public MCP survival integration.','Full normal-tiered JDK21 execution passed without recurrence; the prior JVM root cause remains undetermined. No C1-only workaround or additional root-cause experiments were used.','Per user instruction investigation stops after this non-recurrence and successful acceptance.','Installed JDK distribution and patch level both differ; this is recovery evidence, not proof of a particular upstream fix.','Authored 119-action baseline and previous failures remain separate retained evidence.','Short-design geometry/translation/checker-replay evidence is recorded separately in survival-generation-stop-20261002.json (generated-smoke-c).'],'artifacts':artifacts}
Path('docs/evidence/survival-generation-acceptance-20261002.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'steps':j['completed_steps'],'final':e,'timing':report['timing'],'artifacts_verified':len(artifacts)},indent=2))
