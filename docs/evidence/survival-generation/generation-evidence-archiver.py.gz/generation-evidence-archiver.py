from pathlib import Path
import json,gzip,hashlib,subprocess,re
from datetime import datetime,timezone
base=Path('.local'); dest=Path('docs/evidence/survival-generation');dest.mkdir(exist_ok=True)
pins={'generated-preflight-a':'e468160','generated-preflight-b':'57c7409','generated-smoke-a':'b386962','generated-smoke-b':'24952f3','generated-preflight-c':'24952f3','generated-preflight-d':'a46cc6b','generated-preflight-e':'c0251f1','generated-preflight-f':'b017e6e','generated-preflight-g':'ede002e','generated-preflight-h':'c67410a'}
artifacts=[]
def archive(src,name=None):
 data=src.read_bytes(); packed=gzip.compress(data,mtime=0);out=dest/((name or src.name)+'.gz')
 if out.exists(): assert gzip.decompress(out.read_bytes())==data, str(out)
 else: out.write_bytes(packed)
 packed=out.read_bytes(); assert gzip.decompress(packed)==data
 artifacts.append({'path':'survival-generation/'+out.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'gzip_sha256':hashlib.sha256(packed).hexdigest()})
cases=[]
for case,pin in pins.items():
 stem='survival-roof-20261002-'+case
 if not (base/(stem+'-server.log')).exists(): continue
 x=json.loads((base/(stem+'.json')).read_text());h=x['history']
 assert x['execute'] is False and x['disconnect_error'] is None
 assert all(h[k] is None for k in ('mining','mining_retirement','placement','survival_motion'))
 assert h['motion']['last_submission'] is None
 assert all(t['complete'] for t in x['traces']) and x['observer_trace']['complete']
 log=(base/(stem+'-test.log')).read_text()
 case_record={'case':case,'source':subprocess.check_output(['git','rev-parse',pin],text=True).strip(),'execute':False,'passed':x['error'] is None,'error':x['error'],'construction_dispatch_absent_in_native_history':True,'retained_receive_windows_complete':True,'test_seconds_including_fixture':float(re.findall(r'finished in ([\d.]+)s',log)[-1])}
 outputs=[]
 for e in x['events']:
  if e['phase']=='generated_plan_result':
   result=e['result'];case_record['limits']=e['limits']
   if 'Err' in result: case_record['search_failure']=result['Err']
   else: case_record['generated_plan_steps']=len(result['Ok']['plan']['steps']);case_record['search']=result['Ok']['search']
  if e['phase']=='generated_smoke':
   result=e['result'];out={'design':e['case'],'passed': 'Ok' in result}
   if 'Ok' in result:
    out.update(steps=len(result['Ok']['plan']['steps']), search=result['Ok']['search'])
   else: out['failure']=result['Err']
   outputs.append(out)
  if e['phase']=='generated_smoke_checked':
   next(o for o in outputs if o['design']==e['case']).update(full_replay_equal=e['full_replay_equal'],failed_branch_isolated=e['failed_branch_isolated'],shortage=e['shortage'],limited=e['limited'])
 if outputs: case_record['designs']=outputs
 cases.append(case_record)
 for suffix in ('.json','-test.log','-server-console.log','-server.log'): archive(base/(stem+suffix))
for p in sorted(base.glob('survival-generator-*.log')): archive(p)
archive(base/'run-roof-trial.py','generation-trial-controller.py')
archive(Path(__file__),'generation-evidence-archiver.py')
r={'schema':'dustroute.survival-generation-progress.v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'status':'in_progress_not_generated_roof_acceptance','native_vendor_source':json.loads(Path('vendor/voxrig-source.json').read_text())['revision'],'stage_2_complete':False,'generated_roof_live_execution_completed':False,'fixture':'fresh isolated vanilla Java 1.21.11 localhost:25572; survival setup console only; construction execution disabled','invocation':'DUSTROUTE_SURVIVAL_ROOF_PLANNER=generated (or smoke); DUSTROUTE_SURVIVAL_ROOF_CHECKS as per limits; python3 .local/run-roof-trial.py CASE; no --execute','cases':cases,'limits':['Small-design comparisons and partial hypothetical roof progress are not live construction acceptance.','Candidate checks include refused extensions and can invoke multiple native guards; they are not a physics-call count.','Search is incomplete; exhausted budgets do not prove physical impossibility.','The common executor and native guards remain required before any actual action.'],'artifacts':artifacts}
Path('docs/evidence/survival-generation-progress-20261002.json').write_text(json.dumps(r,indent=2)+'\n')
print('Archived',len(cases),'completed trials and',len(artifacts),'artifacts; all hashes verified.')
