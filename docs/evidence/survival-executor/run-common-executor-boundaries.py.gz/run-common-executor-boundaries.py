import asyncio, os, pathlib, shutil, json, time
ROOT=pathlib.Path('/root/DustRoute')
SERVER=ROOT/'.local/survival-mining-server-20261002'
EXE=ROOT/'target/debug/deps/dustroute_mcp-c5f303da5dd46b65'
FIXTURE='fill -5 -61 -5 12 -61 8 minecraft:stone\nfill -5 -60 -5 12 -53 8 minecraft:air\ntp NatMineBot 0.5 -60 0.5\ntp NatMineView 0.5 -60 5.5\nclear NatMineBot\nitem replace entity NatMineBot inventory.0 with minecraft:dirt 3\n'
async def run(case):
    name=f'common-executor-20261002-{case}'
    out=ROOT/'.local'/f'{name}.json'
    assert not out.exists()
    p=SERVER/'server.properties'
    p.write_text('\n'.join(f'level-name={name}' if l.startswith('level-name=') else l for l in p.read_text().splitlines())+'\n')
    ready=asyncio.Event()
    server=await asyncio.create_subprocess_exec('java','-XX:ActiveProcessorCount=1','-Xms256m','-Xmx768M','-jar',str(ROOT/'.local/minecraft-server-1.21.11/server.jar'),'nogui',cwd=SERVER,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
    async def server_output():
        with open(ROOT/'.local'/f'{name}-server-console.log','xb') as log:
            async for line in server.stdout:
                log.write(line);log.flush()
                if b'Done (' in line: ready.set()
    pump=asyncio.create_task(server_output())
    start=time.monotonic()
    try:
        await asyncio.wait_for(ready.wait(),60)
        print(case,'server ready',flush=True)
        env=dict(os.environ,DUSTROUTE_SURVIVAL_ACCESS_PORT='25572',DUSTROUTE_SURVIVAL_ACCESS_OUTPUT=str(out))
        env.pop('DUSTROUTE_SURVIVAL_ACCESS_INJECT_HAND',None)
        env['DUSTROUTE_SURVIVAL_ACCESS_BOUNDARY']=case.split('-')[0] if case!='natural-b' else ''
        test=await asyncio.create_subprocess_exec(str(EXE),'--exact','survival_navigation::native_access_trial::native_temporary_access_place_climb_retreat_cleanup','--ignored','--nocapture','--test-threads=1',cwd=ROOT,env=env,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
        async def trial_output():
            with open(ROOT/'.local'/f'{name}-test.log','xb') as log:
                async for line in test.stdout:
                    log.write(line);log.flush()
                    if b'FIXTURE access:' in line:
                        server.stdin.write(FIXTURE.encode());await server.stdin.drain()
                        await asyncio.sleep(0.3)
                        test.stdin.write(b'\n');await test.stdin.drain()
                    if b'FIXTURE target:' in line:
                        server.stdin.write(b'setblock 1 -60 0 minecraft:stone\n');await server.stdin.drain()
                        await asyncio.sleep(0.3)
                        test.stdin.write(b'\n');await test.stdin.drain()
                    if b'test result:' in line or b'panicked' in line: print(case,line.decode().strip(),flush=True)
        await asyncio.wait_for(trial_output(),90)
        code=await test.wait()
        assert code==0, (case,code)
        data=json.loads(out.read_text());assert data['error'] is None, data['error']
        print(case,'verified',data['events'][-1]['phase'],flush=True)
    finally:
        if server.returncode is None:
            server.stdin.write(b'stop\n');await server.stdin.drain()
            code=await asyncio.wait_for(server.wait(),30)
            assert code==0, ('server',case,code)
        await pump
        shutil.copyfile(SERVER/'logs/latest.log',ROOT/'.local'/f'{name}-server.log')
        print(case,'server stopped',round(time.monotonic()-start,2),'s total',flush=True)
async def main():
    for case in ['cancel-a','disconnect-a','target-a','natural-b']:
        await run(case)
asyncio.run(main())
