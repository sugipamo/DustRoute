import asyncio,os,pathlib,shutil,sys,json,time
ROOT=pathlib.Path('/root/DustRoute');SERVER=ROOT/'.local/survival-mining-server-20261002'
EXE=ROOT/'target/debug/deps/dustroute_mcp-c5f303da5dd46b65'
case=sys.argv[1];live='--execute' in sys.argv[2:]
assert case.replace('-','').isalnum()
name=f'survival-roof-20261002-{case}';out=ROOT/'.local'/f'{name}.json'
FIXTURE='fill -5 -61 -5 9 -61 10 minecraft:stone\nfill -5 -60 -5 9 -50 10 minecraft:air\ntp NatMineBot 2.5 -60 7.5\ntp NatMineView 7.5 -60 2.5\nclear NatMineBot\nitem replace entity NatMineBot inventory.0 with minecraft:cobblestone 49\nitem replace entity NatMineBot inventory.1 with minecraft:dirt 32\n'
async def run():
 assert not out.exists()
 p=SERVER/'server.properties';p.write_text('\n'.join(f'level-name={name}' if l.startswith('level-name=') else l for l in p.read_text().splitlines())+'\n')
 ready=asyncio.Event()
 server=await asyncio.create_subprocess_exec('java','-XX:ActiveProcessorCount=1','-Xms256m','-Xmx768M','-jar',str(ROOT/'.local/minecraft-server-1.21.11/server.jar'),'nogui',cwd=SERVER,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
 async def server_output():
  with open(ROOT/'.local'/f'{name}-server-console.log','xb') as log:
   async for line in server.stdout:
    log.write(line);log.flush()
    if b'Done (' in line: ready.set()
 pump=asyncio.create_task(server_output());start=time.monotonic()
 try:
  await asyncio.wait_for(ready.wait(),60);print('server ready',flush=True)
  env=dict(os.environ,DUSTROUTE_SURVIVAL_ROOF_PORT='25572',DUSTROUTE_SURVIVAL_ROOF_OUTPUT=str(out),DUSTROUTE_SURVIVAL_ROOF_EXECUTE='1' if live else '0')
  test=await asyncio.create_subprocess_exec(str(EXE),'--exact','survival_construction::native_roof_trial::native_fixed_roof','--ignored','--nocapture','--test-threads=1',cwd=ROOT,env=env,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
  async def trial_output():
   with open(ROOT/'.local'/f'{name}-test.log','xb') as log:
    async for line in test.stdout:
     log.write(line);log.flush()
     if b'FIXTURE roof:' in line:
      server.stdin.write(FIXTURE.encode());await server.stdin.drain();await asyncio.sleep(0.3);test.stdin.write(b'\n');await test.stdin.drain()
     elif line.strip(): print(line.decode().strip(),flush=True)
  await asyncio.wait_for(trial_output(),1200 if live else 180)
  code=await test.wait();print('trial exit',code,flush=True)
  if out.stat().st_size:
   x=json.loads(out.read_text());print('result',json.dumps({'error':x['error'],'events':len(x['events']),'last_event':x['events'][-1]['phase'] if x['events'] else None}),flush=True)
  return code
 finally:
  if server.returncode is None:
   server.stdin.write(b'stop\n');await server.stdin.drain();code=await asyncio.wait_for(server.wait(),30);assert code==0
  await pump
  shutil.copyfile(SERVER/'logs/latest.log',ROOT/'.local'/f'{name}-server.log')
  print('server stopped',round(time.monotonic()-start,2),'s total',flush=True)
sys.exit(asyncio.run(run()))
