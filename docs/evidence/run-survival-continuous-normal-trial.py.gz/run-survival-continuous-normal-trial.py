import asyncio, hashlib, json, os, pathlib, socket, subprocess, sys, time
ROOT = pathlib.Path('/root/DustRoute')
DUST = pathlib.Path('/root/DustRoute')
NAME = 'survival-continuous-20261005-normal-a'
FIXTURE = DUST / '.local' / NAME
EXE = ROOT / 'target/debug/deps/dustroute_mcp-c997675eb353238b'
JAR = DUST / '.local/minecraft-server-1.21.11/server.jar'
JAVA = DUST / '.local/jdks/jdk-21.0.12.1+1/bin/java'
OUTPUT = ROOT / '.local' / (NAME + '.json')
META = ROOT / '.local' / (NAME + '-runtime.json')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
async def run():
    assert not FIXTURE.exists() and not OUTPUT.exists() and not META.exists()
    probe = socket.socket(); probe.bind(('127.0.0.1', 25572)); probe.close()
    FIXTURE.mkdir()
    properties = {'server-ip':'127.0.0.1','server-port':'25572','online-mode':'false', 'enforce-secure-profile':'false','enforce-whitelist':'true','white-list':'true','gamemode':'survival','force-gamemode':'true','difficulty':'peaceful','spawn-protection':'0','max-players':'2','view-distance':'5','simulation-distance':'5','level-name':'world','level-type':'minecraft:flat','level-seed':'943062','generate-structures':'false','enable-rcon':'false','management-server-enabled':'false','sync-chunk-writes':'true', 'generator-settings':json.dumps({'biome':'minecraft:plains','features':False,'lakes':False,'layers':[{'block':'minecraft:bedrock','height':1},{'block':'minecraft:stone','height':3}]},separators=(',',':'))}
    (FIXTURE/'server.properties').write_text('\n'.join(k+'='+v for k,v in properties.items())+'\n')
    (FIXTURE/'eula.txt').write_bytes((DUST/'.local/survival-mining-server-20261002/eula.txt').read_bytes())
    entries=json.loads((DUST/'.local/survival-mining-server-20261002/whitelist.json').read_text())
    selected=[v for v in entries if v['name'] in ['NatMineBot','NatMineView']]
    assert {v['name'] for v in selected} == {'NatMineBot','NatMineView'}
    (FIXTURE/'whitelist.json').write_text(json.dumps(selected)+'\n')
    (FIXTURE/'ops.json').write_text('[]\n')
    env=dict(os.environ)
    removed=[k for k in ['JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS'] if env.pop(k,None) is not None]
    ver=subprocess.run([str(JAVA),'-version'],env=env,text=True,capture_output=True,check=True)
    metadata={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'dirty':subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip(),'java':str(JAVA),'java_version':ver.stdout+ver.stderr,'java_sha256':digest(JAVA),'server_jar_sha256':digest(JAR),'test_executable_sha256':digest(EXE),'flags':['-XX:ActiveProcessorCount=1','-Xms256m','-Xmx768M'],'removed_java_option_environment_names':removed,'endpoint':'127.0.0.1:25572','fixture':str(FIXTURE),'setup_batches':[]}
    def save():META.write_text(json.dumps(metadata,indent=2)+'\n')
    save()
    assert not metadata['dirty'], 'immutable source required'
    ready=asyncio.Event();start=time.monotonic()
    server=await asyncio.create_subprocess_exec(str(JAVA),*metadata['flags'],'-jar',str(JAR),'nogui',cwd=FIXTURE,env=env,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
    metadata['server_pid']=server.pid;save()
    async def server_output():
        with (ROOT/'.local'/(NAME+'-server-console.log')).open('xb') as f:
            async for line in server.stdout:
                f.write(line);f.flush()
                if b'Done (' in line:ready.set()
    pump=asyncio.create_task(server_output())
    try:
        await asyncio.wait_for(ready.wait(),180)
        print('isolated server ready',flush=True)
        testenv=dict(env,DUSTROUTE_SURVIVAL_ROOF_PORT='25572',DUSTROUTE_SURVIVAL_ROOF_OUTPUT=str(OUTPUT),DUSTROUTE_SURVIVAL_ROOF_EXECUTE='1')
        trial=await asyncio.create_subprocess_exec(str(EXE),'--exact','service::survival::tests::native_public_roof','--ignored','--test-threads=1','--nocapture',cwd=ROOT,env=testenv,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
        metadata['test_pid']=trial.pid;save()
        with (ROOT/'.local'/(NAME+'-test.log')).open('xb') as f:
            async for line in trial.stdout:
                f.write(line);f.flush()
                commands=None
                if b'FIXTURE roof:' in line:
                    commands=['fill -5 -61 -5 9 -61 10 minecraft:stone','fill -5 -60 -5 9 -50 10 minecraft:air','tp NatMineBot 2.5 -60 7.5','tp NatMineView 7.5 -60 2.5','clear NatMineBot','item replace entity NatMineBot inventory.0 with minecraft:cobblestone 49','item replace entity NatMineBot inventory.1 with minecraft:dirt 32']
                if commands is not None:
                    metadata['setup_batches'].append({'elapsed_seconds':time.monotonic()-start,'commands':commands});save()
                    server.stdin.write(('\n'.join(commands)+'\n').encode());await server.stdin.drain()
                    await asyncio.sleep(0.15)
                    trial.stdin.write(b'\n');await trial.stdin.drain()
                elif line.strip():print(line.decode().strip(),flush=True)
        code=await trial.wait();metadata['test_exit_code']=code;save()
        print('native test exit',code,flush=True)
        return code
    finally:
        if server.returncode is None:
            server.stdin.write(b'stop\n');await server.stdin.drain();await asyncio.wait_for(server.wait(),45)
        await pump
        metadata['server_exit_code']=await server.wait();metadata['total_seconds']=time.monotonic()-start;save()
        print('server exit',metadata['server_exit_code'],flush=True)
        assert metadata['server_exit_code']==0
sys.exit(asyncio.run(run()))
