import asyncio, hashlib, json, os, pathlib, re, socket, subprocess, time, uuid
ROOT = pathlib.Path('/root/DustRoute')
NAME = 'native-only-bridge-20261003-a'
FIXTURE = ROOT / '.local' / NAME
EXE = ROOT / 'target/debug/examples/voxrig_bridge_probe'
JAR = ROOT / '.local/minecraft-server-1.21.11/server.jar'
JAVA = ROOT / '.local/jdks/jdk-21.0.12.1+1/bin/java'
OUTPUT = ROOT / '.local' / (NAME + '.json')
META = ROOT / '.local' / (NAME + '-runtime.json')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def account(name):
    return {'name':name,'uuid':str(uuid.UUID(bytes=hashlib.md5(('OfflinePlayer:'+name).encode()).digest(),version=3))}
async def run():
    assert not FIXTURE.exists() and not OUTPUT.exists() and not META.exists()
    probe=socket.socket();probe.bind(('127.0.0.1',25572));probe.close()
    FIXTURE.mkdir()
    properties={'server-ip':'127.0.0.1','server-port':'25572','online-mode':'false','enforce-secure-profile':'false','white-list':'true','enforce-whitelist':'true','gamemode':'creative','force-gamemode':'true','difficulty':'peaceful','spawn-protection':'0','max-players':'2','view-distance':'5','simulation-distance':'5','level-name':'world','level-type':'minecraft:flat','level-seed':'943062','generate-structures':'false','enable-rcon':'false','management-server-enabled':'false','sync-chunk-writes':'true','generator-settings':json.dumps({'biome':'minecraft:plains','features':False,'lakes':False,'layers':[{'block':'minecraft:bedrock','height':1},{'block':'minecraft:stone','height':3}]},separators=(',',':'))}
    (FIXTURE/'server.properties').write_text('\n'.join(k+'='+v for k,v in properties.items())+'\n')
    (FIXTURE/'eula.txt').write_bytes((ROOT/'.local/survival-mining-server-20261002/eula.txt').read_bytes())
    (FIXTURE/'whitelist.json').write_text(json.dumps([account('BridgeProbe'),account('AimProbe')])+'\n')
    (FIXTURE/'ops.json').write_text(json.dumps([{**account('BridgeProbe'),'level':4,'bypassesPlayerLimit':False}])+'\n')
    env=dict(os.environ)
    removed=[k for k in ['JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS'] if env.pop(k,None) is not None]
    metadata={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'dirty':subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip(),'endpoint':'127.0.0.1:25572','java_sha256':digest(JAVA),'server_jar_sha256':digest(JAR),'test_executable_sha256':digest(EXE),'controller_sha256':digest(pathlib.Path(__file__)),'fixture':str(FIXTURE),'flags':['-XX:ActiveProcessorCount=1','-Xms256m','-Xmx768M'],'removed_java_option_environment_names':removed,'setup_batches':[]}
    assert not metadata['dirty'],'immutable source required'
    def save():META.write_text(json.dumps(metadata,indent=2)+'\n')
    save(); ready=asyncio.Event();fence=asyncio.Event();cells=set();start=time.monotonic()
    server=await asyncio.create_subprocess_exec(str(JAVA),*metadata['flags'],'-jar',str(JAR),'nogui',cwd=FIXTURE,env=env,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
    metadata['server_pid']=server.pid;save()
    async def server_output():
        with (ROOT/'.local'/(NAME+'-server-console.log')).open('xb') as f:
            async for line in server.stdout:
                f.write(line);f.flush()
                if b'Done (' in line:ready.set()
                match=re.search(rb'\[Server\] NATIVE_CELL_(\d+)_(\d+)_(\d+)',line)
                if match:cells.add(tuple(int(v) for v in match.groups()))
                if b'[Server] NATIVE_CHECK_FENCE' in line:fence.set()
    pump=asyncio.create_task(server_output())
    trial=None; mcp=None
    async def commands(rows):
        metadata['setup_batches'].append({'elapsed_seconds':time.monotonic()-start,'commands':rows});save()
        server.stdin.write(('\n'.join(rows)+'\n').encode());await server.stdin.drain()
    try:
        await asyncio.wait_for(ready.wait(),180)
        print('isolated native bridge server ready',flush=True)
        trial=await asyncio.create_subprocess_exec(str(EXE),cwd=ROOT,env=dict(env,MC_PORT='25572',TRACE_OUTPUT=str(OUTPUT)),stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
        metadata['test_pid']=trial.pid;save()
        with (ROOT/'.local'/(NAME+'-test.log')).open('xb') as f:
            async for line in trial.stdout:
                f.write(line);f.flush()
                if b'READY; creative both' in line:
                    await commands(['fill 98 180 98 106 187 106 minecraft:air','fill 98 179 98 106 179 106 minecraft:stone','gamemode creative BridgeProbe','gamemode creative AimProbe','tp BridgeProbe 100.5 182 103.5','tp AimProbe 104.5 182 103.5 180 0'])
                    await asyncio.sleep(1)
                    trial.stdin.write(b'\n');await trial.stdin.drain()
                elif b'NATIVE_BRIDGE_MATCH;' in line:
                    expected={(100,180,100):'minecraft:stone',(100,181,100):'minecraft:lever[face=floor,facing=north,powered=true]',(102,180,100):'minecraft:stone',(104,183,100):'minecraft:stone',(106,181,100):'minecraft:stone'}
                    rows=[f'execute if block {x} {y} {z} {expected.get((x,y,z),"minecraft:air")} run say NATIVE_CELL_{x}_{y}_{z}' for x in range(98,107) for y in range(180,188) for z in range(98,107)]
                    await commands(rows+['say NATIVE_CHECK_FENCE'])
                    await asyncio.wait_for(fence.wait(),60)
                    metadata['independent_confirmed_cells']=len(cells);save()
                    assert len(cells)==648, len(cells)
                    trial.stdin.write(b'\n');await trial.stdin.drain()
        metadata['test_exit_code']=await asyncio.wait_for(trial.wait(),30);save()
        assert metadata['test_exit_code']==0
        report=json.loads(OUTPUT.read_text());assert report['error'] is None
        metadata['capture_sha256']=digest(OUTPUT);save()
        # Exercise the standard production startup without a backend override.
        await asyncio.sleep(0.5)
        mcp_env={k:v for k,v in env.items() if not k.startswith('DUSTROUTE_')}
        mcp_env.update(DUSTROUTE_SERVER_ADDRESS='127.0.0.1:25572',DUSTROUTE_ASSIST_PLAYER='AimProbe',DUSTROUTE_BOT_NAME='BridgeProbe')
        with (ROOT/'.local'/(NAME+'-mcp-stderr.log')).open('xb') as stderr:
            mcp=await asyncio.create_subprocess_exec(str(ROOT/'target/debug/dustroute-mcp'),cwd=ROOT,env=mcp_env,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=stderr)
            metadata['mcp_pid']=mcp.pid;save()
            async def send(message):
                mcp.stdin.write((json.dumps(message)+'\n').encode());await mcp.stdin.drain()
            async def response(identifier):
                while True:
                    line=await asyncio.wait_for(mcp.stdout.readline(),60)
                    assert line,'MCP transport closed before response'
                    value=json.loads(line)
                    if value.get('id')==identifier:return value
            await send({'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'native-only-acceptance','version':'1'}}})
            initialization=await response(1);assert 'result' in initialization,initialization
            await send({'jsonrpc':'2.0','method':'notifications/initialized'})
            await send({'jsonrpc':'2.0','id':2,'method':'tools/call','params':{'name':'get_bot_status','arguments':{}}})
            status_response=await response(2);assert 'result' in status_response,status_response
            status=json.loads(status_response['result']['content'][0]['text'])
            assert status['ok'] and status['bot']['connected'],status
            metadata['default_backend_status']=status
            metadata['mcp_executable_sha256']=digest(ROOT/'target/debug/dustroute-mcp');save()
            mcp.stdin.close()
            metadata['mcp_exit_code']=await asyncio.wait_for(mcp.wait(),30);save()
            assert metadata['mcp_exit_code']==0
        await commands(['fill 98 180 98 106 187 106 minecraft:air','fill 98 179 98 106 179 106 minecraft:air'])
        print('native bridge trial passed; independently checked 648 cells',flush=True)
    finally:
        try:
            for client in [trial,mcp]:
                if client and client.returncode is None:
                    client.stdin.close()
                    await asyncio.wait_for(client.wait(),30)
        finally:
            server.stdin.write(b'stop\n');await server.stdin.drain()
            metadata['server_exit_code']=await asyncio.wait_for(server.wait(),60)
            await pump
            metadata['elapsed_seconds']=time.monotonic()-start;save()
            assert metadata['server_exit_code']==0
asyncio.run(run())
