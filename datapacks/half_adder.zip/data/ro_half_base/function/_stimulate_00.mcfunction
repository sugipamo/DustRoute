tellraw @a {"text":"HALF 00: STIMULATE","color":"blue"}
schedule function ro_half_base:check_00 60t replace
