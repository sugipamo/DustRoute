tellraw @a {"text":"DAG baseline half-adder","color":"gold"}
tellraw @a {"text":"A source: (-1,3,8)  B source: (-1,3,16)","color":"white"}
tellraw @a {"text":"SUM wire: (50,3,0)  CARRY wire: (26,3,24)","color":"white"}
tellraw @a {"text":"Use /function ro_half_base:case_00 .. case_11 or /function ro_half_base:tests","color":"aqua"}
