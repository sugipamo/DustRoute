tellraw @a {"text":"HALF 10: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~8 minecraft:redstone_block replace
schedule function ro_half_base:check_10 60t replace
