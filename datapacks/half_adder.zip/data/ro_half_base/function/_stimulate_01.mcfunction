tellraw @a {"text":"HALF 01: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~16 minecraft:redstone_block replace
schedule function ro_half_base:check_01 60t replace
