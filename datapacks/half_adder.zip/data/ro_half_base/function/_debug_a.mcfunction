tellraw @a {"text":"A fan-out diagnostic (current state)","color":"gold"}
execute unless block ~ ~3 ~8 minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS A external input: ON","color":"green"}
execute if block ~ ~3 ~8 minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL A external input: OFF","color":"red"}
execute unless block ~2 ~3 ~8 minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS A buffered Net source: ON","color":"green"}
execute if block ~2 ~3 ~8 minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL A buffered Net source: OFF","color":"red"}
execute unless block ~11 ~2 ~8 minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS A sink 0: ON","color":"green"}
execute if block ~11 ~2 ~8 minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL A sink 0: OFF","color":"red"}
execute unless block ~23 ~2 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS A sink 1: ON","color":"green"}
execute if block ~23 ~2 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL A sink 1: OFF","color":"red"}
execute unless block ~11 ~2 ~24 minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS A sink 2: ON","color":"green"}
execute if block ~11 ~2 ~24 minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL A sink 2: OFF","color":"red"}
