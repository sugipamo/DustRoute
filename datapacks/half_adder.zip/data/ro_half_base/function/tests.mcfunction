function ro_half_base:build
tellraw @a {"text":"DAG baseline half-adder: running 00, 01, 10, 11","color":"gold"}
schedule function ro_half_base:case_00 2t replace
schedule function ro_half_base:case_01 74t replace
schedule function ro_half_base:case_10 146t replace
schedule function ro_half_base:case_11 218t replace
