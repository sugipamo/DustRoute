tellraw @a {"text":"HALF 11: expected SUM=0 CARRY=1","color":"gray"}
execute if block ~50 ~3 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS SUM=0","color":"green"}
execute unless block ~50 ~3 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL SUM: expected 0","color":"red"}
execute if block ~26 ~3 ~24 minecraft:redstone_wire unless block ~26 ~3 ~24 minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS CARRY=1","color":"green"}
execute unless block ~26 ~3 ~24 minecraft:redstone_wire run tellraw @a {"text":"FAIL CARRY: output wire missing","color":"red"}
execute if block ~26 ~3 ~24 minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL CARRY: expected 1","color":"red"}
