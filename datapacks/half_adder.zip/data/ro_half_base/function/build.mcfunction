kill @e[type=minecraft:marker,tag=ro_half_base_origin]
summon minecraft:marker ~ ~ ~ {Tags:["ro_half_base_origin"]}
execute at @e[type=minecraft:marker,tag=ro_half_base_origin,limit=1] run function ro_half_base:_build
