execute at @e[type=minecraft:marker,tag=ro_half_base_origin,limit=1] run function ro_half_base:_case_00
