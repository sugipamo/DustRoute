setblock ~-1 ~3 ~8 minecraft:air replace
setblock ~-1 ~3 ~16 minecraft:air replace
function ro_half_base:_build
schedule function ro_half_base:stimulate_10 4t replace
