tellraw @a {"text":"half subtractor validation","color":"gold"}
tellraw @a {"text":"/function ro_halfsub:halfsub/tests","color":"aqua"}
