tellraw @a {"text":"halfsub 01: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~16 minecraft:redstone_block replace
schedule function ro_halfsub:halfsub/check_01 60t replace
