setblock ~-1 ~3 ~8 minecraft:air replace
setblock ~-1 ~3 ~16 minecraft:air replace
function ro_halfsub:halfsub/_build
schedule function ro_halfsub:halfsub/stimulate_01 4t replace
