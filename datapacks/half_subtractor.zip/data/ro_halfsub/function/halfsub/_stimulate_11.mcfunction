tellraw @a {"text":"halfsub 11: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~8 minecraft:redstone_block replace
setblock ~-1 ~3 ~16 minecraft:redstone_block replace
schedule function ro_halfsub:halfsub/check_11 60t replace
