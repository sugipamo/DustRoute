kill @e[type=minecraft:marker,tag=ro_halfsub_halfsub_origin]
summon minecraft:marker ~ ~ ~ {Tags:["ro_halfsub_halfsub_origin"]}
execute at @e[type=minecraft:marker,tag=ro_halfsub_halfsub_origin,limit=1] run function ro_halfsub:halfsub/_build
