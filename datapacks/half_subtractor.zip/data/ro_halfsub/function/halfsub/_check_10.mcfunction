tellraw @a {"text":"halfsub 10: expected diff=1 borrow=0","color":"gray"}
execute if block ~50 ~3 ~ minecraft:redstone_wire unless block ~50 ~3 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS DIFF=1","color":"green"}
execute if block ~50 ~3 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL DIFF: expected 1","color":"red"}
execute if block ~38 ~3 ~24 minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS BORROW=0","color":"green"}
execute unless block ~38 ~3 ~24 minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL BORROW: expected 0","color":"red"}
