function ro_halfsub:halfsub/build
tellraw @a {"text":"halfsub: running 4 truth-table cases","color":"gold"}
schedule function ro_halfsub:halfsub/case_00 2t replace
schedule function ro_halfsub:halfsub/case_01 74t replace
schedule function ro_halfsub:halfsub/case_10 146t replace
schedule function ro_halfsub:halfsub/case_11 218t replace
