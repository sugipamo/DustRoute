tellraw @a {"text":"halfsub 01: expected diff=1 borrow=1","color":"gray"}
execute if block ~50 ~3 ~ minecraft:redstone_wire unless block ~50 ~3 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS DIFF=1","color":"green"}
execute if block ~50 ~3 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL DIFF: expected 1","color":"red"}
execute if block ~38 ~3 ~24 minecraft:redstone_wire unless block ~38 ~3 ~24 minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS BORROW=1","color":"green"}
execute if block ~38 ~3 ~24 minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL BORROW: expected 1","color":"red"}
