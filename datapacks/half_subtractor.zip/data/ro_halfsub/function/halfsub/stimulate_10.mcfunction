execute at @e[type=minecraft:marker,tag=ro_halfsub_halfsub_origin,limit=1] run function ro_halfsub:halfsub/_stimulate_10
