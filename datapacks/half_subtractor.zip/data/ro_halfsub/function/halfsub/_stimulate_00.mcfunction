tellraw @a {"text":"halfsub 00: STIMULATE","color":"blue"}
schedule function ro_halfsub:halfsub/check_00 60t replace
