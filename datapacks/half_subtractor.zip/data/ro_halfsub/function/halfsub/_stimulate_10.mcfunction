tellraw @a {"text":"halfsub 10: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~8 minecraft:redstone_block replace
schedule function ro_halfsub:halfsub/check_10 60t replace
