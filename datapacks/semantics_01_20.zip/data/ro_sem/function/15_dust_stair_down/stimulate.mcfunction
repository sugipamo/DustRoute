execute at @e[type=minecraft:marker,tag=ro_sem_15_dust_stair_down_origin,limit=1] run function ro_sem:15_dust_stair_down/_stimulate
