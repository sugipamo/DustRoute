tellraw @a {"text":"15_dust_stair_down: CHECK","color":"gray"}
execute unless block ~1 ~1 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS dust stair down","color":"green"}
execute if block ~1 ~1 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL dust stair down: wire is OFF","color":"red"}
