fill ~-3 ~-2 ~-3 ~4 ~5 ~3 minecraft:air replace minecraft:redstone_wire
fill ~-3 ~-2 ~-3 ~4 ~5 ~3 minecraft:air replace minecraft:repeater
fill ~-3 ~-2 ~-3 ~4 ~5 ~3 minecraft:air replace minecraft:comparator
fill ~-3 ~-2 ~-3 ~4 ~5 ~3 minecraft:air replace minecraft:redstone_torch
fill ~-3 ~-2 ~-3 ~4 ~5 ~3 minecraft:air replace minecraft:redstone_wall_torch
fill ~-3 ~-2 ~-3 ~4 ~5 ~3 minecraft:air replace minecraft:lever
fill ~-3 ~-2 ~-3 ~4 ~5 ~3 minecraft:air replace
execute positioned ~-3 ~-2 ~-3 run kill @e[type=minecraft:item,dx=7,dy=7,dz=6]
fill ~-3 ~-1 ~-3 ~4 ~-1 ~3 minecraft:stone replace
setblock ~1 ~ ~ minecraft:stone replace
setblock ~ ~1 ~ minecraft:stone replace
setblock ~1 ~1 ~ minecraft:redstone_wire[north=none,east=none,south=none,west=up,power=0] replace
setblock ~ ~2 ~ minecraft:redstone_wire[north=none,east=side,south=none,west=none,power=0] replace
tellraw @a {"text":"15_dust_stair_down: BUILD - dust descends one block through valid stair geometry","color":"yellow"}
