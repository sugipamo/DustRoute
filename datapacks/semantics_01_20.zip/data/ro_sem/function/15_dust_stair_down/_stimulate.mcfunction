setblock ~-1 ~2 ~ minecraft:redstone_block replace
tellraw @a {"text":"15_dust_stair_down: STIMULATE","color":"blue"}
