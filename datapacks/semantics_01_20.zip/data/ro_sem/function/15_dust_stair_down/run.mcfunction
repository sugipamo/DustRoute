function ro_sem:15_dust_stair_down/build
schedule function ro_sem:15_dust_stair_down/stimulate 4t replace
schedule function ro_sem:15_dust_stair_down/check 24t replace
