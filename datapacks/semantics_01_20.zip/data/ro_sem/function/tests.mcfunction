kill @e[type=minecraft:marker,tag=ro_sem_suite_origin]
summon minecraft:marker ~ ~ ~ {Tags:["ro_sem_suite_origin"]}
tellraw @a {"text":"Simulator semantics probes: same-origin BUILD -> STIMULATE -> CHECK","color":"gold"}
function ro_sem:_launch_01_source_to_dust
schedule function ro_sem:_launch_02_dust_decay 28t replace
schedule function ro_sem:_launch_03_weak_block_no_dust_return 56t replace
schedule function ro_sem:_launch_04_weak_block_to_repeater 84t replace
schedule function ro_sem:_launch_05_repeater_refresh 112t replace
schedule function ro_sem:_launch_06_repeater_strong_block 140t replace
schedule function ro_sem:_launch_07_torch_unpowered_support 168t replace
schedule function ro_sem:_launch_08_torch_powered_support 196t replace
schedule function ro_sem:_launch_09_redstone_block_no_block_propagation 224t replace
schedule function ro_sem:_launch_10_dust_repeater_dust 252t replace
schedule function ro_sem:_launch_11_repeater_reverse_blocked 280t replace
schedule function ro_sem:_launch_12_dust_to_repeater_input 308t replace
schedule function ro_sem:_launch_13_dust_corner 336t replace
schedule function ro_sem:_launch_14_dust_stair_up 364t replace
schedule function ro_sem:_launch_15_dust_stair_down 392t replace
schedule function ro_sem:_launch_16_leaf_dust_block_power 420t replace
schedule function ro_sem:_launch_17_branch_leaf_block_power 448t replace
schedule function ro_sem:_launch_18_repeater_route_block_power 476t replace
schedule function ro_sem:_launch_19_cell_output_to_block_input 504t replace
schedule function ro_sem:_launch_20_repeater_to_corner 532t replace
tellraw @a {"text":"Automatic probes reuse one loaded test bench; use /gallery for spatial inspection.","color":"aqua"}
