fill ~-2 ~-2 ~-3 ~6 ~4 ~3 minecraft:air replace minecraft:redstone_wire
fill ~-2 ~-2 ~-3 ~6 ~4 ~3 minecraft:air replace minecraft:repeater
fill ~-2 ~-2 ~-3 ~6 ~4 ~3 minecraft:air replace minecraft:comparator
fill ~-2 ~-2 ~-3 ~6 ~4 ~3 minecraft:air replace minecraft:redstone_torch
fill ~-2 ~-2 ~-3 ~6 ~4 ~3 minecraft:air replace minecraft:redstone_wall_torch
fill ~-2 ~-2 ~-3 ~6 ~4 ~3 minecraft:air replace minecraft:lever
fill ~-2 ~-2 ~-3 ~6 ~4 ~3 minecraft:air replace
execute positioned ~-2 ~-2 ~-3 run kill @e[type=minecraft:item,dx=8,dy=6,dz=6]
fill ~-2 ~-1 ~-3 ~6 ~-1 ~3 minecraft:stone replace
setblock ~1 ~ ~ minecraft:stone replace
setblock ~2 ~ ~ minecraft:stone replace
setblock ~3 ~ ~ minecraft:stone replace
setblock ~1 ~1 ~ minecraft:redstone_wire[north=none,east=side,south=none,west=none,power=0] replace
setblock ~2 ~1 ~ minecraft:redstone_wire[north=none,east=side,south=none,west=side,power=0] replace
setblock ~3 ~1 ~ minecraft:redstone_wire[north=none,east=none,south=none,west=side,power=0] replace
tellraw @a {"text":"02_dust_decay: BUILD - dust propagates 15,14,13","color":"yellow"}
