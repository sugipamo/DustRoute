tellraw @a {"text":"02_dust_decay: CHECK","color":"gray"}
execute if block ~1 ~1 ~ minecraft:redstone_wire[power=15] run tellraw @a {"text":"PASS dust[0] = 15","color":"green"}
execute unless block ~1 ~1 ~ minecraft:redstone_wire[power=15] run tellraw @a {"text":"FAIL dust[0]: expected power 15","color":"red"}
execute if block ~2 ~1 ~ minecraft:redstone_wire[power=14] run tellraw @a {"text":"PASS dust[1] = 14","color":"green"}
execute unless block ~2 ~1 ~ minecraft:redstone_wire[power=14] run tellraw @a {"text":"FAIL dust[1]: expected power 14","color":"red"}
execute if block ~3 ~1 ~ minecraft:redstone_wire[power=13] run tellraw @a {"text":"PASS dust[2] = 13","color":"green"}
execute unless block ~3 ~1 ~ minecraft:redstone_wire[power=13] run tellraw @a {"text":"FAIL dust[2]: expected power 13","color":"red"}
