execute at @e[type=minecraft:marker,tag=ro_sem_02_dust_decay_origin,limit=1] run function ro_sem:02_dust_decay/_stimulate
