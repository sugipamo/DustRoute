setblock ~ ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"02_dust_decay: STIMULATE","color":"blue"}
