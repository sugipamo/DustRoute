kill @e[type=minecraft:marker,tag=ro_sem_17_branch_leaf_block_power_origin]
summon minecraft:marker ~ ~ ~ {Tags:["ro_sem_17_branch_leaf_block_power_origin"]}
execute at @e[type=minecraft:marker,tag=ro_sem_17_branch_leaf_block_power_origin,limit=1] run function ro_sem:17_branch_leaf_block_power/_build
