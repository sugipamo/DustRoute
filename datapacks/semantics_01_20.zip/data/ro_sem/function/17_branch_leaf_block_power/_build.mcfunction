fill ~-3 ~-2 ~-3 ~7 ~4 ~4 minecraft:air replace minecraft:redstone_wire
fill ~-3 ~-2 ~-3 ~7 ~4 ~4 minecraft:air replace minecraft:repeater
fill ~-3 ~-2 ~-3 ~7 ~4 ~4 minecraft:air replace minecraft:comparator
fill ~-3 ~-2 ~-3 ~7 ~4 ~4 minecraft:air replace minecraft:redstone_torch
fill ~-3 ~-2 ~-3 ~7 ~4 ~4 minecraft:air replace minecraft:redstone_wall_torch
fill ~-3 ~-2 ~-3 ~7 ~4 ~4 minecraft:air replace minecraft:lever
fill ~-3 ~-2 ~-3 ~7 ~4 ~4 minecraft:air replace
execute positioned ~-3 ~-2 ~-3 run kill @e[type=minecraft:item,dx=10,dy=6,dz=7]
fill ~-3 ~-1 ~-3 ~7 ~-1 ~4 minecraft:stone replace
setblock ~ ~ ~ minecraft:stone replace
setblock ~1 ~ ~ minecraft:stone replace
setblock ~1 ~ ~1 minecraft:stone replace
setblock ~2 ~ ~ minecraft:stone replace
setblock ~3 ~1 ~ minecraft:stone replace
setblock ~ ~1 ~ minecraft:redstone_wire[north=none,east=side,south=none,west=none,power=0] replace
setblock ~1 ~1 ~ minecraft:redstone_wire[north=none,east=side,south=side,west=side,power=0] replace
setblock ~1 ~1 ~1 minecraft:redstone_wire[north=side,east=none,south=none,west=none,power=0] replace
setblock ~2 ~1 ~ minecraft:redstone_wire[north=none,east=none,south=none,west=side,power=0] replace
setblock ~4 ~1 ~ minecraft:redstone_wall_torch[facing=east,lit=true] replace
tellraw @a {"text":"17_branch_leaf_block_power: BUILD - fan-out junction feeds a separate leaf BLOCK_POWER stub","color":"yellow"}
