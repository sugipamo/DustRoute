setblock ~-1 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"17_branch_leaf_block_power: STIMULATE","color":"blue"}
