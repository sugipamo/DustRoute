tellraw @a {"text":"17_branch_leaf_block_power: CHECK","color":"gray"}
execute unless block ~1 ~1 ~1 minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS fan-out side branch","color":"green"}
execute if block ~1 ~1 ~1 minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL fan-out side branch: wire is OFF","color":"red"}
execute if block ~4 ~1 ~ minecraft:redstone_wall_torch[lit=false] run tellraw @a {"text":"PASS fan-out leaf -> BLOCK_POWER","color":"green"}
execute if block ~4 ~1 ~ minecraft:redstone_wall_torch[lit=true] run tellraw @a {"text":"FAIL fan-out leaf -> BLOCK_POWER","color":"red"}
