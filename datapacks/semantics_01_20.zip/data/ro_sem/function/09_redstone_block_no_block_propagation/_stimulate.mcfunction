setblock ~-1 ~ ~ minecraft:redstone_block replace
tellraw @a {"text":"09_redstone_block_no_block_propagation: STIMULATE","color":"blue"}
