tellraw @a {"text":"09_redstone_block_no_block_propagation: CHECK","color":"gray"}
execute if block ~1 ~ ~ minecraft:redstone_wall_torch[lit=true] run tellraw @a {"text":"PASS redstone block beside support -> torch stays ON","color":"green"}
execute if block ~1 ~ ~ minecraft:redstone_wall_torch[lit=false] run tellraw @a {"text":"FAIL redstone block beside support -> torch stays ON","color":"red"}
