execute at @e[type=minecraft:marker,tag=ro_sem_09_redstone_block_no_block_propagation_origin,limit=1] run function ro_sem:09_redstone_block_no_block_propagation/_check
