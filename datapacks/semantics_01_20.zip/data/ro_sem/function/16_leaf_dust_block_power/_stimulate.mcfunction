setblock ~-1 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"16_leaf_dust_block_power: STIMULATE","color":"blue"}
