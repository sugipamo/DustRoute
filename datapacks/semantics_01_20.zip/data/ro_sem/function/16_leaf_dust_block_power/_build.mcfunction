fill ~-3 ~-2 ~-3 ~5 ~4 ~3 minecraft:air replace minecraft:redstone_wire
fill ~-3 ~-2 ~-3 ~5 ~4 ~3 minecraft:air replace minecraft:repeater
fill ~-3 ~-2 ~-3 ~5 ~4 ~3 minecraft:air replace minecraft:comparator
fill ~-3 ~-2 ~-3 ~5 ~4 ~3 minecraft:air replace minecraft:redstone_torch
fill ~-3 ~-2 ~-3 ~5 ~4 ~3 minecraft:air replace minecraft:redstone_wall_torch
fill ~-3 ~-2 ~-3 ~5 ~4 ~3 minecraft:air replace minecraft:lever
fill ~-3 ~-2 ~-3 ~5 ~4 ~3 minecraft:air replace
execute positioned ~-3 ~-2 ~-3 run kill @e[type=minecraft:item,dx=8,dy=6,dz=6]
fill ~-3 ~-1 ~-3 ~5 ~-1 ~3 minecraft:stone replace
setblock ~ ~ ~ minecraft:stone replace
setblock ~1 ~1 ~ minecraft:stone replace
setblock ~ ~1 ~ minecraft:redstone_wire[north=none,east=none,south=none,west=none,power=0] replace
setblock ~2 ~1 ~ minecraft:redstone_wall_torch[facing=east,lit=true] replace
tellraw @a {"text":"16_leaf_dust_block_power: BUILD - leaf dust powers the adjacent support block","color":"yellow"}
