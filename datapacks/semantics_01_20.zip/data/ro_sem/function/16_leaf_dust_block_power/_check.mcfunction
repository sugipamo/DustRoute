tellraw @a {"text":"16_leaf_dust_block_power: CHECK","color":"gray"}
execute if block ~2 ~1 ~ minecraft:redstone_wall_torch[lit=false] run tellraw @a {"text":"PASS leaf dust -> BLOCK_POWER","color":"green"}
execute if block ~2 ~1 ~ minecraft:redstone_wall_torch[lit=true] run tellraw @a {"text":"FAIL leaf dust -> BLOCK_POWER","color":"red"}
