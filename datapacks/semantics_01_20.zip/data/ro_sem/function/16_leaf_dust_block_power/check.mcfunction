execute at @e[type=minecraft:marker,tag=ro_sem_16_leaf_dust_block_power_origin,limit=1] run function ro_sem:16_leaf_dust_block_power/_check
