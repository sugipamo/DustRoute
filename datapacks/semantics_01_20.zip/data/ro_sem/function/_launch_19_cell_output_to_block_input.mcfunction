execute at @e[type=minecraft:marker,tag=ro_sem_suite_origin,limit=1] run function ro_sem:19_cell_output_to_block_input/run
