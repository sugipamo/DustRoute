tellraw @a {"text":"08_torch_powered_support: CHECK","color":"gray"}
execute if block ~1 ~1 ~ minecraft:redstone_wall_torch[lit=false] run tellraw @a {"text":"PASS dust -> support -> torch OFF","color":"green"}
execute if block ~1 ~1 ~ minecraft:redstone_wall_torch[lit=true] run tellraw @a {"text":"FAIL dust -> support -> torch OFF","color":"red"}
