fill ~-4 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:redstone_wire
fill ~-4 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:repeater
fill ~-4 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:comparator
fill ~-4 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:redstone_torch
fill ~-4 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:redstone_wall_torch
fill ~-4 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:lever
fill ~-4 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace
execute positioned ~-4 ~-2 ~-3 run kill @e[type=minecraft:item,dx=8,dy=6,dz=6]
fill ~-4 ~-1 ~-3 ~4 ~-1 ~3 minecraft:stone replace
setblock ~-1 ~ ~ minecraft:stone replace
setblock ~ ~1 ~ minecraft:stone replace
setblock ~-1 ~1 ~ minecraft:redstone_wire[north=none,east=none,south=none,west=none,power=0] replace
setblock ~1 ~1 ~ minecraft:redstone_wall_torch[facing=east,lit=true] replace
tellraw @a {"text":"08_torch_powered_support: BUILD - dust-powered support block turns its attached torch off","color":"yellow"}
