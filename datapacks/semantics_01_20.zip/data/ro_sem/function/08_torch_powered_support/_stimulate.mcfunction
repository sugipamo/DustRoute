setblock ~-2 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"08_torch_powered_support: STIMULATE","color":"blue"}
