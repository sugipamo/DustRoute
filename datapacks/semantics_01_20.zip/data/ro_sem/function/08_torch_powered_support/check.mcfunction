execute at @e[type=minecraft:marker,tag=ro_sem_08_torch_powered_support_origin,limit=1] run function ro_sem:08_torch_powered_support/_check
