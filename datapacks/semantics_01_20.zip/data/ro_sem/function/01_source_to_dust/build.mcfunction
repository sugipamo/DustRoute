kill @e[type=minecraft:marker,tag=ro_sem_01_source_to_dust_origin]
summon minecraft:marker ~ ~ ~ {Tags:["ro_sem_01_source_to_dust_origin"]}
execute at @e[type=minecraft:marker,tag=ro_sem_01_source_to_dust_origin,limit=1] run function ro_sem:01_source_to_dust/_build
