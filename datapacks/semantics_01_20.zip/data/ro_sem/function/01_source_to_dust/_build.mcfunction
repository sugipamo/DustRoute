fill ~-2 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:redstone_wire
fill ~-2 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:repeater
fill ~-2 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:comparator
fill ~-2 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:redstone_torch
fill ~-2 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:redstone_wall_torch
fill ~-2 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:lever
fill ~-2 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace
execute positioned ~-2 ~-2 ~-3 run kill @e[type=minecraft:item,dx=6,dy=6,dz=6]
fill ~-2 ~-1 ~-3 ~4 ~-1 ~3 minecraft:stone replace
setblock ~1 ~ ~ minecraft:stone replace
setblock ~1 ~1 ~ minecraft:redstone_wire[north=none,east=none,south=none,west=none,power=0] replace
tellraw @a {"text":"01_source_to_dust: BUILD - redstone block directly drives adjacent dust","color":"yellow"}
