setblock ~ ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"01_source_to_dust: STIMULATE","color":"blue"}
