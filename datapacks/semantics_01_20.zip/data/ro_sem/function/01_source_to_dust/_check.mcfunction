tellraw @a {"text":"01_source_to_dust: CHECK","color":"gray"}
execute if block ~1 ~1 ~ minecraft:redstone_wire[power=15] run tellraw @a {"text":"PASS source -> dust = 15","color":"green"}
execute unless block ~1 ~1 ~ minecraft:redstone_wire[power=15] run tellraw @a {"text":"FAIL source -> dust: expected power 15","color":"red"}
