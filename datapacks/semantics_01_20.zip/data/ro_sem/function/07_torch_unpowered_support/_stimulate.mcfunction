tellraw @a {"text":"07_torch_unpowered_support: STIMULATE","color":"blue"}
