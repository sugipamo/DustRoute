fill ~-3 ~-2 ~-3 ~4 ~3 ~3 minecraft:air replace minecraft:redstone_wire
fill ~-3 ~-2 ~-3 ~4 ~3 ~3 minecraft:air replace minecraft:repeater
fill ~-3 ~-2 ~-3 ~4 ~3 ~3 minecraft:air replace minecraft:comparator
fill ~-3 ~-2 ~-3 ~4 ~3 ~3 minecraft:air replace minecraft:redstone_torch
fill ~-3 ~-2 ~-3 ~4 ~3 ~3 minecraft:air replace minecraft:redstone_wall_torch
fill ~-3 ~-2 ~-3 ~4 ~3 ~3 minecraft:air replace minecraft:lever
fill ~-3 ~-2 ~-3 ~4 ~3 ~3 minecraft:air replace
execute positioned ~-3 ~-2 ~-3 run kill @e[type=minecraft:item,dx=7,dy=5,dz=6]
fill ~-3 ~-1 ~-3 ~4 ~-1 ~3 minecraft:stone replace
setblock ~ ~ ~ minecraft:stone replace
setblock ~1 ~ ~ minecraft:redstone_wall_torch[facing=east,lit=true] replace
tellraw @a {"text":"07_torch_unpowered_support: BUILD - attached torch is lit when its support block is unpowered","color":"yellow"}
