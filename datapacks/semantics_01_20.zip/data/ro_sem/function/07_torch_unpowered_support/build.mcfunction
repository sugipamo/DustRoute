kill @e[type=minecraft:marker,tag=ro_sem_07_torch_unpowered_support_origin]
summon minecraft:marker ~ ~ ~ {Tags:["ro_sem_07_torch_unpowered_support_origin"]}
execute at @e[type=minecraft:marker,tag=ro_sem_07_torch_unpowered_support_origin,limit=1] run function ro_sem:07_torch_unpowered_support/_build
