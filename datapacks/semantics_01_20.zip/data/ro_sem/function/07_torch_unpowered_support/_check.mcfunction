tellraw @a {"text":"07_torch_unpowered_support: CHECK","color":"gray"}
execute if block ~1 ~ ~ minecraft:redstone_wall_torch[lit=true] run tellraw @a {"text":"PASS torch support OFF -> torch ON","color":"green"}
execute if block ~1 ~ ~ minecraft:redstone_wall_torch[lit=false] run tellraw @a {"text":"FAIL torch support OFF -> torch ON","color":"red"}
