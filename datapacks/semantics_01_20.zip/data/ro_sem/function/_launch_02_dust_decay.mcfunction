execute at @e[type=minecraft:marker,tag=ro_sem_suite_origin,limit=1] run function ro_sem:02_dust_decay/run
