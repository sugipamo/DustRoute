tellraw @a {"text":"19_cell_output_to_block_input: CHECK","color":"gray"}
execute if block ~6 ~1 ~ minecraft:redstone_wall_torch[lit=false] run tellraw @a {"text":"PASS cell output -> route -> cell input","color":"green"}
execute if block ~6 ~1 ~ minecraft:redstone_wall_torch[lit=true] run tellraw @a {"text":"FAIL cell output -> route -> cell input","color":"red"}
