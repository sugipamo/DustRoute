setblock ~-1 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"19_cell_output_to_block_input: STIMULATE","color":"blue"}
