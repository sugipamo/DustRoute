execute at @e[type=minecraft:marker,tag=ro_sem_11_repeater_reverse_blocked_origin,limit=1] run function ro_sem:11_repeater_reverse_blocked/_check
