setblock ~3 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"11_repeater_reverse_blocked: STIMULATE","color":"blue"}
