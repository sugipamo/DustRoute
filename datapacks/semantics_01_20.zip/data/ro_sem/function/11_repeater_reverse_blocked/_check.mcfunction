tellraw @a {"text":"11_repeater_reverse_blocked: CHECK","color":"gray"}
execute if block ~ ~1 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS repeater reverse direction blocked","color":"green"}
execute unless block ~ ~1 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL repeater reverse direction blocked: wire is ON","color":"red"}
