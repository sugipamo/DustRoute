setblock ~2 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"04_weak_block_to_repeater: STIMULATE","color":"blue"}
