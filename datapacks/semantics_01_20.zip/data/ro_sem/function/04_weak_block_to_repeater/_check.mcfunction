tellraw @a {"text":"04_weak_block_to_repeater: CHECK","color":"gray"}
execute unless block ~-2 ~1 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS weak block -> repeater","color":"green"}
execute if block ~-2 ~1 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL weak block -> repeater: wire is OFF","color":"red"}
