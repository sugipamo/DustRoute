fill ~-5 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:redstone_wire
fill ~-5 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:repeater
fill ~-5 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:comparator
fill ~-5 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:redstone_torch
fill ~-5 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:redstone_wall_torch
fill ~-5 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace minecraft:lever
fill ~-5 ~-2 ~-3 ~4 ~4 ~3 minecraft:air replace
execute positioned ~-5 ~-2 ~-3 run kill @e[type=minecraft:item,dx=9,dy=6,dz=6]
fill ~-5 ~-1 ~-3 ~4 ~-1 ~3 minecraft:stone replace
setblock ~-2 ~ ~ minecraft:stone replace
setblock ~-1 ~ ~ minecraft:stone replace
setblock ~1 ~ ~ minecraft:stone replace
setblock ~ ~1 ~ minecraft:stone replace
setblock ~-2 ~1 ~ minecraft:redstone_wire[north=none,east=side,south=none,west=none,power=0] replace
setblock ~-1 ~1 ~ minecraft:repeater[delay=1,facing=east,locked=false,powered=false] replace
setblock ~1 ~1 ~ minecraft:redstone_wire[north=none,east=none,south=none,west=none,power=0] replace
tellraw @a {"text":"04_weak_block_to_repeater: BUILD - repeater reads a solid block weak-powered by dust","color":"yellow"}
