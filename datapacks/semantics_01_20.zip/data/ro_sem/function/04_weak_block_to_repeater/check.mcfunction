execute at @e[type=minecraft:marker,tag=ro_sem_04_weak_block_to_repeater_origin,limit=1] run function ro_sem:04_weak_block_to_repeater/_check
