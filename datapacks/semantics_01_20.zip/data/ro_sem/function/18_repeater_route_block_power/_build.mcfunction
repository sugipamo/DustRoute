fill ~-3 ~-2 ~-3 ~8 ~4 ~3 minecraft:air replace minecraft:redstone_wire
fill ~-3 ~-2 ~-3 ~8 ~4 ~3 minecraft:air replace minecraft:repeater
fill ~-3 ~-2 ~-3 ~8 ~4 ~3 minecraft:air replace minecraft:comparator
fill ~-3 ~-2 ~-3 ~8 ~4 ~3 minecraft:air replace minecraft:redstone_torch
fill ~-3 ~-2 ~-3 ~8 ~4 ~3 minecraft:air replace minecraft:redstone_wall_torch
fill ~-3 ~-2 ~-3 ~8 ~4 ~3 minecraft:air replace minecraft:lever
fill ~-3 ~-2 ~-3 ~8 ~4 ~3 minecraft:air replace
execute positioned ~-3 ~-2 ~-3 run kill @e[type=minecraft:item,dx=11,dy=6,dz=6]
fill ~-3 ~-1 ~-3 ~8 ~-1 ~3 minecraft:stone replace
setblock ~ ~ ~ minecraft:stone replace
setblock ~1 ~ ~ minecraft:stone replace
setblock ~2 ~ ~ minecraft:stone replace
setblock ~3 ~ ~ minecraft:stone replace
setblock ~4 ~ ~ minecraft:stone replace
setblock ~4 ~1 ~ minecraft:stone replace
setblock ~ ~1 ~ minecraft:redstone_wire[north=none,east=side,south=none,west=none,power=0] replace
setblock ~1 ~1 ~ minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~2 ~1 ~ minecraft:redstone_wire[north=none,east=side,south=none,west=side,power=0] replace
setblock ~3 ~1 ~ minecraft:redstone_wire[north=none,east=none,south=none,west=side,power=0] replace
setblock ~5 ~1 ~ minecraft:redstone_wall_torch[facing=east,lit=true] replace
tellraw @a {"text":"18_repeater_route_block_power: BUILD - repeater -> routed dust -> BLOCK_POWER leaf","color":"yellow"}
