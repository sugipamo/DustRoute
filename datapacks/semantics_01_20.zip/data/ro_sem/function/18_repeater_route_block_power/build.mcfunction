kill @e[type=minecraft:marker,tag=ro_sem_18_repeater_route_block_power_origin]
summon minecraft:marker ~ ~ ~ {Tags:["ro_sem_18_repeater_route_block_power_origin"]}
execute at @e[type=minecraft:marker,tag=ro_sem_18_repeater_route_block_power_origin,limit=1] run function ro_sem:18_repeater_route_block_power/_build
