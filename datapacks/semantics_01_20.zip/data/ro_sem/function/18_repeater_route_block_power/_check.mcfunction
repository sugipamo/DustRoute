tellraw @a {"text":"18_repeater_route_block_power: CHECK","color":"gray"}
execute if block ~5 ~1 ~ minecraft:redstone_wall_torch[lit=false] run tellraw @a {"text":"PASS repeater route -> BLOCK_POWER","color":"green"}
execute if block ~5 ~1 ~ minecraft:redstone_wall_torch[lit=true] run tellraw @a {"text":"FAIL repeater route -> BLOCK_POWER","color":"red"}
