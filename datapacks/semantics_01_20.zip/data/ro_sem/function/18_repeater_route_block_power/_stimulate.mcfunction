setblock ~-1 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"18_repeater_route_block_power: STIMULATE","color":"blue"}
