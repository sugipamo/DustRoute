function ro_sem:20_repeater_to_corner/build
schedule function ro_sem:20_repeater_to_corner/stimulate 4t replace
schedule function ro_sem:20_repeater_to_corner/check 24t replace
