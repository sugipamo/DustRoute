execute at @e[type=minecraft:marker,tag=ro_sem_20_repeater_to_corner_origin,limit=1] run function ro_sem:20_repeater_to_corner/_stimulate
