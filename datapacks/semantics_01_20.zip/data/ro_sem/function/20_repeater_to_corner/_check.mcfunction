tellraw @a {"text":"20_repeater_to_corner: CHECK","color":"gray"}
execute unless block ~2 ~1 ~2 minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS repeater -> corner -> dust","color":"green"}
execute if block ~2 ~1 ~2 minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL repeater -> corner -> dust: wire is OFF","color":"red"}
