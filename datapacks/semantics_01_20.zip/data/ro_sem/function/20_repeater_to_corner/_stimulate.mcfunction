setblock ~-1 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"20_repeater_to_corner: STIMULATE","color":"blue"}
