fill ~-3 ~-2 ~-3 ~5 ~4 ~5 minecraft:air replace minecraft:redstone_wire
fill ~-3 ~-2 ~-3 ~5 ~4 ~5 minecraft:air replace minecraft:repeater
fill ~-3 ~-2 ~-3 ~5 ~4 ~5 minecraft:air replace minecraft:comparator
fill ~-3 ~-2 ~-3 ~5 ~4 ~5 minecraft:air replace minecraft:redstone_torch
fill ~-3 ~-2 ~-3 ~5 ~4 ~5 minecraft:air replace minecraft:redstone_wall_torch
fill ~-3 ~-2 ~-3 ~5 ~4 ~5 minecraft:air replace minecraft:lever
fill ~-3 ~-2 ~-3 ~5 ~4 ~5 minecraft:air replace
execute positioned ~-3 ~-2 ~-3 run kill @e[type=minecraft:item,dx=8,dy=6,dz=8]
fill ~-3 ~-1 ~-3 ~5 ~-1 ~5 minecraft:stone replace
setblock ~ ~ ~ minecraft:stone replace
setblock ~1 ~ ~ minecraft:stone replace
setblock ~2 ~ ~ minecraft:stone replace
setblock ~2 ~ ~1 minecraft:stone replace
setblock ~2 ~ ~2 minecraft:stone replace
setblock ~ ~1 ~ minecraft:redstone_wire[north=none,east=side,south=none,west=none,power=0] replace
setblock ~1 ~1 ~ minecraft:repeater[delay=1,facing=west,locked=false,powered=false] replace
setblock ~2 ~1 ~ minecraft:redstone_wire[north=none,east=none,south=side,west=side,power=0] replace
setblock ~2 ~1 ~1 minecraft:redstone_wire[north=side,east=none,south=side,west=none,power=0] replace
setblock ~2 ~1 ~2 minecraft:redstone_wire[north=side,east=none,south=none,west=none,power=0] replace
tellraw @a {"text":"20_repeater_to_corner: BUILD - repeater output remains connected through an immediate dust corner","color":"yellow"}
