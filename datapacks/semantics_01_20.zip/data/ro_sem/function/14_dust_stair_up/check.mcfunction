execute at @e[type=minecraft:marker,tag=ro_sem_14_dust_stair_up_origin,limit=1] run function ro_sem:14_dust_stair_up/_check
