setblock ~-1 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"14_dust_stair_up: STIMULATE","color":"blue"}
