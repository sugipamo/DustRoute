function ro_sem:14_dust_stair_up/build
schedule function ro_sem:14_dust_stair_up/stimulate 4t replace
schedule function ro_sem:14_dust_stair_up/check 24t replace
