tellraw @a {"text":"14_dust_stair_up: CHECK","color":"gray"}
execute unless block ~1 ~2 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS dust stair up","color":"green"}
execute if block ~1 ~2 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL dust stair up: wire is OFF","color":"red"}
