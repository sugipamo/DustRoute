execute at @e[type=minecraft:marker,tag=ro_sem_13_dust_corner_origin,limit=1] run function ro_sem:13_dust_corner/_check
