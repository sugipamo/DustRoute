fill ~-3 ~-2 ~-3 ~4 ~4 ~4 minecraft:air replace minecraft:redstone_wire
fill ~-3 ~-2 ~-3 ~4 ~4 ~4 minecraft:air replace minecraft:repeater
fill ~-3 ~-2 ~-3 ~4 ~4 ~4 minecraft:air replace minecraft:comparator
fill ~-3 ~-2 ~-3 ~4 ~4 ~4 minecraft:air replace minecraft:redstone_torch
fill ~-3 ~-2 ~-3 ~4 ~4 ~4 minecraft:air replace minecraft:redstone_wall_torch
fill ~-3 ~-2 ~-3 ~4 ~4 ~4 minecraft:air replace minecraft:lever
fill ~-3 ~-2 ~-3 ~4 ~4 ~4 minecraft:air replace
execute positioned ~-3 ~-2 ~-3 run kill @e[type=minecraft:item,dx=7,dy=6,dz=7]
fill ~-3 ~-1 ~-3 ~4 ~-1 ~4 minecraft:stone replace
setblock ~ ~ ~ minecraft:stone replace
setblock ~1 ~ ~ minecraft:stone replace
setblock ~1 ~ ~1 minecraft:stone replace
setblock ~ ~1 ~ minecraft:redstone_wire[north=none,east=side,south=none,west=none,power=0] replace
setblock ~1 ~1 ~ minecraft:redstone_wire[north=none,east=none,south=side,west=side,power=0] replace
setblock ~1 ~1 ~1 minecraft:redstone_wire[north=side,east=none,south=none,west=none,power=0] replace
tellraw @a {"text":"13_dust_corner: BUILD - dust carries signal around a horizontal corner","color":"yellow"}
