setblock ~-1 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"13_dust_corner: STIMULATE","color":"blue"}
