tellraw @a {"text":"13_dust_corner: CHECK","color":"gray"}
execute unless block ~1 ~1 ~1 minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS dust corner","color":"green"}
execute if block ~1 ~1 ~1 minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL dust corner: wire is OFF","color":"red"}
