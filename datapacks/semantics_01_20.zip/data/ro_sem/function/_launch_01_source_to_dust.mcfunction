execute at @e[type=minecraft:marker,tag=ro_sem_suite_origin,limit=1] run function ro_sem:01_source_to_dust/run
