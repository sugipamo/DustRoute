execute at @e[type=minecraft:marker,tag=ro_sem_03_weak_block_no_dust_return_origin,limit=1] run function ro_sem:03_weak_block_no_dust_return/_stimulate
