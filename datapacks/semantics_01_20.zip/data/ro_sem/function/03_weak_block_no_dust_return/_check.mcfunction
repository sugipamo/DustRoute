tellraw @a {"text":"03_weak_block_no_dust_return: CHECK","color":"gray"}
execute if block ~-1 ~1 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS weak block -> dust is blocked","color":"green"}
execute unless block ~-1 ~1 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL weak block -> dust is blocked: wire is ON","color":"red"}
