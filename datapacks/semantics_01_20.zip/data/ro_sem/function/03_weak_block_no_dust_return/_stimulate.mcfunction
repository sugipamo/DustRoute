setblock ~2 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"03_weak_block_no_dust_return: STIMULATE","color":"blue"}
