execute at @e[type=minecraft:marker,tag=ro_sem_06_repeater_strong_block_origin,limit=1] run function ro_sem:06_repeater_strong_block/_check
