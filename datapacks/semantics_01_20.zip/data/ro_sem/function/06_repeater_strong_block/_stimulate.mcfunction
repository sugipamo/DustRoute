setblock ~-1 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"06_repeater_strong_block: STIMULATE","color":"blue"}
