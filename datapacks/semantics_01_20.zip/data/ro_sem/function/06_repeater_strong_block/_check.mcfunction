tellraw @a {"text":"06_repeater_strong_block: CHECK","color":"gray"}
execute unless block ~3 ~1 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS repeater -> block -> dust","color":"green"}
execute if block ~3 ~1 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL repeater -> block -> dust: wire is OFF","color":"red"}
