setblock ~-1 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"12_dust_to_repeater_input: STIMULATE","color":"blue"}
