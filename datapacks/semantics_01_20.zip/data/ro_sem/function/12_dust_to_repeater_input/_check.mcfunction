tellraw @a {"text":"12_dust_to_repeater_input: CHECK","color":"gray"}
execute unless block ~3 ~1 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS dust -> repeater input","color":"green"}
execute if block ~3 ~1 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL dust -> repeater input: wire is OFF","color":"red"}
