execute at @e[type=minecraft:marker,tag=ro_sem_12_dust_to_repeater_input_origin,limit=1] run function ro_sem:12_dust_to_repeater_input/_check
