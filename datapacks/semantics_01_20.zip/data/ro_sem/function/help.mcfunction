tellraw @a {"text":"Simulator semantics API","color":"gold"}
tellraw @a {"text":"/function ro_sem:01_source_to_dust/run - redstone block directly drives adjacent dust","color":"white"}
tellraw @a {"text":"/function ro_sem:02_dust_decay/run - dust propagates 15,14,13","color":"white"}
tellraw @a {"text":"/function ro_sem:03_weak_block_no_dust_return/run - dust weak-powers a solid block; that weak power does not emerge as dust","color":"white"}
tellraw @a {"text":"/function ro_sem:04_weak_block_to_repeater/run - repeater reads a solid block weak-powered by dust","color":"white"}
tellraw @a {"text":"/function ro_sem:05_repeater_refresh/run - repeater restores downstream dust to 15","color":"white"}
tellraw @a {"text":"/function ro_sem:06_repeater_strong_block/run - repeater strongly powers a solid block; that block drives adjacent dust","color":"white"}
tellraw @a {"text":"/function ro_sem:07_torch_unpowered_support/run - attached torch is lit when its support block is unpowered","color":"white"}
tellraw @a {"text":"/function ro_sem:08_torch_powered_support/run - dust-powered support block turns its attached torch off","color":"white"}
tellraw @a {"text":"/function ro_sem:09_redstone_block_no_block_propagation/run - redstone block does not propagate powered-block state through adjacent solid","color":"white"}
tellraw @a {"text":"/function ro_sem:10_dust_repeater_dust/run - straight dust -> repeater -> dust connection","color":"white"}
tellraw @a {"text":"/function ro_sem:11_repeater_reverse_blocked/run - repeater does not conduct backwards from output side","color":"white"}
tellraw @a {"text":"/function ro_sem:12_dust_to_repeater_input/run - dust enters the back/input side of a repeater","color":"white"}
tellraw @a {"text":"/function ro_sem:13_dust_corner/run - dust carries signal around a horizontal corner","color":"white"}
tellraw @a {"text":"/function ro_sem:14_dust_stair_up/run - dust climbs one block when the stair geometry is open","color":"white"}
tellraw @a {"text":"/function ro_sem:15_dust_stair_down/run - dust descends one block through valid stair geometry","color":"white"}
tellraw @a {"text":"/function ro_sem:16_leaf_dust_block_power/run - leaf dust powers the adjacent support block","color":"white"}
tellraw @a {"text":"/function ro_sem:17_branch_leaf_block_power/run - fan-out junction feeds a separate leaf BLOCK_POWER stub","color":"white"}
tellraw @a {"text":"/function ro_sem:18_repeater_route_block_power/run - repeater -> routed dust -> BLOCK_POWER leaf","color":"white"}
tellraw @a {"text":"/function ro_sem:19_cell_output_to_block_input/run - buffered cell output crosses routing into BLOCK_POWER input","color":"white"}
tellraw @a {"text":"/function ro_sem:20_repeater_to_corner/run - repeater output remains connected through an immediate dust corner","color":"white"}
