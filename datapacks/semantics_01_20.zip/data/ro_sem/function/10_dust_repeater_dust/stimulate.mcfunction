execute at @e[type=minecraft:marker,tag=ro_sem_10_dust_repeater_dust_origin,limit=1] run function ro_sem:10_dust_repeater_dust/_stimulate
