setblock ~-1 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"10_dust_repeater_dust: STIMULATE","color":"blue"}
