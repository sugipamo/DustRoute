tellraw @a {"text":"10_dust_repeater_dust: CHECK","color":"gray"}
execute if block ~2 ~1 ~ minecraft:redstone_wire[power=15] run tellraw @a {"text":"PASS dust -> repeater -> dust = 15","color":"green"}
execute unless block ~2 ~1 ~ minecraft:redstone_wire[power=15] run tellraw @a {"text":"FAIL dust -> repeater -> dust: expected power 15","color":"red"}
