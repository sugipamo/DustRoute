setblock ~-1 ~1 ~ minecraft:redstone_block replace
tellraw @a {"text":"05_repeater_refresh: STIMULATE","color":"blue"}
