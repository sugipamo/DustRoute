execute at @e[type=minecraft:marker,tag=ro_sem_05_repeater_refresh_origin,limit=1] run function ro_sem:05_repeater_refresh/_check
