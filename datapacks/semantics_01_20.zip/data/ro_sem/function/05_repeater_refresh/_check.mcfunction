tellraw @a {"text":"05_repeater_refresh: CHECK","color":"gray"}
execute if block ~4 ~1 ~ minecraft:redstone_wire[power=15] run tellraw @a {"text":"PASS repeater refresh = 15","color":"green"}
execute unless block ~4 ~1 ~ minecraft:redstone_wire[power=15] run tellraw @a {"text":"FAIL repeater refresh: expected power 15","color":"red"}
