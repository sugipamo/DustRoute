tellraw @a {"text":"DAG circuit validation","color":"gold"}
tellraw @a {"text":"/function ro_circuits:mux/tests","color":"aqua"}
tellraw @a {"text":"/function ro_circuits:decoder/tests","color":"aqua"}
