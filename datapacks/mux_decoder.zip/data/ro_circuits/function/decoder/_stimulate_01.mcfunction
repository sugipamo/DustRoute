tellraw @a {"text":"decoder 01: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~20 minecraft:redstone_block replace
schedule function ro_circuits:decoder/check_01 60t replace
