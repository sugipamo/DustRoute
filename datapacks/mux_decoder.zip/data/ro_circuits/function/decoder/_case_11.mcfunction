setblock ~-1 ~3 ~12 minecraft:air replace
setblock ~-1 ~3 ~20 minecraft:air replace
function ro_circuits:decoder/_build
schedule function ro_circuits:decoder/stimulate_11 4t replace
