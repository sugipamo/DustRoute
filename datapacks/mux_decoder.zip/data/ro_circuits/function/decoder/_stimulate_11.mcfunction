tellraw @a {"text":"decoder 11: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~12 minecraft:redstone_block replace
setblock ~-1 ~3 ~20 minecraft:redstone_block replace
schedule function ro_circuits:decoder/check_11 60t replace
