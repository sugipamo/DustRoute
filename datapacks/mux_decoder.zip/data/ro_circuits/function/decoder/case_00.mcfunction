execute at @e[type=minecraft:marker,tag=ro_circuits_decoder_origin,limit=1] run function ro_circuits:decoder/_case_00
