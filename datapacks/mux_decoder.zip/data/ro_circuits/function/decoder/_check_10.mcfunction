tellraw @a {"text":"decoder 10: expected y0=1 y1=0","color":"gray"}
execute if block ~38 ~3 ~ minecraft:redstone_wire unless block ~38 ~3 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS Y0=1","color":"green"}
execute if block ~38 ~3 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL Y0: expected 1","color":"red"}
execute if block ~26 ~3 ~24 minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS Y1=0","color":"green"}
execute unless block ~26 ~3 ~24 minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL Y1: expected 0","color":"red"}
