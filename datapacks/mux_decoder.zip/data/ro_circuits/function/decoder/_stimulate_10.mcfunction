tellraw @a {"text":"decoder 10: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~12 minecraft:redstone_block replace
schedule function ro_circuits:decoder/check_10 60t replace
