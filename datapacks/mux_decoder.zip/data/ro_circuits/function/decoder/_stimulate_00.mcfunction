tellraw @a {"text":"decoder 00: STIMULATE","color":"blue"}
schedule function ro_circuits:decoder/check_00 60t replace
