kill @e[type=minecraft:marker,tag=ro_circuits_decoder_origin]
summon minecraft:marker ~ ~ ~ {Tags:["ro_circuits_decoder_origin"]}
execute at @e[type=minecraft:marker,tag=ro_circuits_decoder_origin,limit=1] run function ro_circuits:decoder/_build
