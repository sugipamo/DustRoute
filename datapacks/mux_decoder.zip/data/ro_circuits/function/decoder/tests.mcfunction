function ro_circuits:decoder/build
tellraw @a {"text":"decoder: running 4 truth-table cases","color":"gold"}
schedule function ro_circuits:decoder/case_00 2t replace
schedule function ro_circuits:decoder/case_01 74t replace
schedule function ro_circuits:decoder/case_10 146t replace
schedule function ro_circuits:decoder/case_11 218t replace
