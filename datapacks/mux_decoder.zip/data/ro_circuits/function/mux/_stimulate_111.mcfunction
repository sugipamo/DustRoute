tellraw @a {"text":"mux 111: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~ minecraft:redstone_block replace
setblock ~-1 ~3 ~8 minecraft:redstone_block replace
setblock ~-1 ~3 ~16 minecraft:redstone_block replace
schedule function ro_circuits:mux/check_111 60t replace
