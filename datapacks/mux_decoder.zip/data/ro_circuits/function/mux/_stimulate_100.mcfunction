tellraw @a {"text":"mux 100: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~ minecraft:redstone_block replace
schedule function ro_circuits:mux/check_100 60t replace
