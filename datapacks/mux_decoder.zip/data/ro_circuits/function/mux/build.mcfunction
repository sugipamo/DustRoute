kill @e[type=minecraft:marker,tag=ro_circuits_mux_origin]
summon minecraft:marker ~ ~ ~ {Tags:["ro_circuits_mux_origin"]}
execute at @e[type=minecraft:marker,tag=ro_circuits_mux_origin,limit=1] run function ro_circuits:mux/_build
