setblock ~-1 ~3 ~ minecraft:air replace
setblock ~-1 ~3 ~8 minecraft:air replace
setblock ~-1 ~3 ~16 minecraft:air replace
function ro_circuits:mux/_build
schedule function ro_circuits:mux/stimulate_011 4t replace
