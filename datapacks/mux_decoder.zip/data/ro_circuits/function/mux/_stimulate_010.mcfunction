tellraw @a {"text":"mux 010: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~8 minecraft:redstone_block replace
schedule function ro_circuits:mux/check_010 60t replace
