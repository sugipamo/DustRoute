tellraw @a {"text":"mux 101: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~ minecraft:redstone_block replace
setblock ~-1 ~3 ~16 minecraft:redstone_block replace
schedule function ro_circuits:mux/check_101 60t replace
