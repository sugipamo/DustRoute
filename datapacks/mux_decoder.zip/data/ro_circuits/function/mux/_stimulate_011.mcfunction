tellraw @a {"text":"mux 011: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~8 minecraft:redstone_block replace
setblock ~-1 ~3 ~16 minecraft:redstone_block replace
schedule function ro_circuits:mux/check_011 60t replace
