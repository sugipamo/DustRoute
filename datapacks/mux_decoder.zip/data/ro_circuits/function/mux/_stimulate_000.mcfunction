tellraw @a {"text":"mux 000: STIMULATE","color":"blue"}
schedule function ro_circuits:mux/check_000 60t replace
