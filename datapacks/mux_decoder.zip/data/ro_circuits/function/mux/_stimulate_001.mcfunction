tellraw @a {"text":"mux 001: STIMULATE","color":"blue"}
setblock ~-1 ~3 ~16 minecraft:redstone_block replace
schedule function ro_circuits:mux/check_001 60t replace
