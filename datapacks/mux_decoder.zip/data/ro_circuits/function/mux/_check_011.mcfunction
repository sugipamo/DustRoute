tellraw @a {"text":"mux 011: expected out=1","color":"gray"}
execute if block ~50 ~3 ~ minecraft:redstone_wire unless block ~50 ~3 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS OUT=1","color":"green"}
execute if block ~50 ~3 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL OUT: expected 1","color":"red"}
