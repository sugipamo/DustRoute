tellraw @a {"text":"mux 010: expected out=0","color":"gray"}
execute if block ~50 ~3 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"PASS OUT=0","color":"green"}
execute unless block ~50 ~3 ~ minecraft:redstone_wire[power=0] run tellraw @a {"text":"FAIL OUT: expected 0","color":"red"}
