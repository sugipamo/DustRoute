function ro_circuits:mux/build
tellraw @a {"text":"mux: running 8 truth-table cases","color":"gold"}
schedule function ro_circuits:mux/case_000 2t replace
schedule function ro_circuits:mux/case_001 74t replace
schedule function ro_circuits:mux/case_010 146t replace
schedule function ro_circuits:mux/case_011 218t replace
schedule function ro_circuits:mux/case_100 290t replace
schedule function ro_circuits:mux/case_101 362t replace
schedule function ro_circuits:mux/case_110 434t replace
schedule function ro_circuits:mux/case_111 506t replace
