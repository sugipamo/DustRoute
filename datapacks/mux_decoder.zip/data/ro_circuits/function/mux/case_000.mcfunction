execute at @e[type=minecraft:marker,tag=ro_circuits_mux_origin,limit=1] run function ro_circuits:mux/_case_000
